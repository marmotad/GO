package base

import (
	"github.com/astaxie/beego"
)

// BaseController 所有业务控制器基础控制器
type BaseController struct {
	beego.Controller
}
